<?php
   setcookie("trui", "1", time()+1000); 
	setcookie("broek", "1", time()+1000); 
	var_dump($_COOKIE);
    

    ?>