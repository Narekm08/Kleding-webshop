<?php
echo "Hoeveel broeken: " . $_COOKIE['broek']; 
echo "Hoeveel truien: "  . $_COOKIE['trui'];
    
?>